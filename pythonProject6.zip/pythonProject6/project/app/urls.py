from django.urls import path
from .views import index, myForm, user

urlpatterns = [
    path('', index, name='home'),
    path('myform', myForm, name='form'),
    path('user', user, name='user'),
]