from django import forms

class UserForm(forms.Form):
    name = forms.CharField(max_length=20, min_length=2)
    age = forms.IntegerField(max_value=50)
    agree = forms.BooleanField(label='Согласен на обработку персональных данных:')
    email = forms.EmailField()
    url = forms.URLField()
    file = forms.FileField()
    photo = forms.ImageField()
    date = forms.DateTimeField()





















